
#include "SceneGClear.h"

// �R���X�g���N�^
SceneGClear::SceneGClear()
{
	s_stateID = SceneStateID::INIT;
}

// �v�Z����
bool SceneGClear::Loop()
{
	bool res = false;

	switch (s_stateID)
	{

	case SceneStateID::INIT:
	{
		Init();
		Load(CLEAR_PATH);
		s_stateID = SceneStateID::STEP;
	}
	break;

	case SceneStateID::STEP:
	{
		mInput.Update();
		if (mInput.IsPush(KEY_INPUT_RETURN))
			s_stateID = SceneStateID::FIN;
	}
	break;

	case SceneStateID::FIN:
	{
		Fin();
		s_stateID = SceneStateID::INIT;
		res = true;
	}
	break;

	}

	return res;
}
