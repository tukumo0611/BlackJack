
#include "SceneGOver.h"

// �R���X�g���N�^
SceneGOver::SceneGOver()
{
	s_stateID = SceneStateID::INIT;
}

// �v�Z����
bool SceneGOver::Loop()
{
	bool res = false;

	switch (s_stateID)
	{

	case SceneStateID::INIT:
	{
		Init();
		Load(GAMEOVER_PATH);
		s_stateID = SceneStateID::STEP;
	}
	break;

	case SceneStateID::STEP:
	{
		mInput.Update();
		if (mInput.IsPush(KEY_INPUT_RETURN))
			s_stateID = SceneStateID::FIN;
	}
	break;

	case SceneStateID::FIN:
	{
		Fin();
		s_stateID = SceneStateID::INIT;
		res = true;
	}
	break;

	}

	return res;
}
