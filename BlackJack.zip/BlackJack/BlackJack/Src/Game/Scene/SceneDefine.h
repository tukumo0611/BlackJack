
#pragma once

constexpr char TITLE_PATH[] = "Data/Title/Title.png";
constexpr char CLEAR_PATH[] = "Data/Title/Clear.png";
constexpr char GAMEOVER_PATH[] = "Data/Title/GameOver.png";
constexpr char BACKGROUND_PATH[] = "Data/Title/Table.png";


constexpr int INITIALIZATION = -1;
