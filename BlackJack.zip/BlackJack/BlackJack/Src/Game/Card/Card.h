
#pragma once
#include <DxLib.h>
#include "CardDefine.h"

class Card
{
	VECTOR Pos;
	VECTOR MovePos;
	int Hndl, BackHndl;
	double Rate, Angle;
	bool IsActive;
	bool IsOPEN;

public:
	Card();

	void Init();

	void Load(const char* CardHndl);

	void Step();

	void Draw();

	void Fin();

	void Move(VECTOR MovePos);

	void SetPos(VECTOR pos) { Pos = pos; }
	void SetMovePos(VECTOR movepos) { MovePos = movepos; }
	void SetIsActive(bool flag) { IsActive = flag; }
	void SetIsOPEN(bool flag) { IsOPEN = flag; }

	VECTOR GetPos() const { return Pos; }
	VECTOR GetMovePos() const { return MovePos; }
	bool GetIsActive() const { return IsActive; }
	bool GetIsOPEN() const { return IsOPEN; }

};
