
#pragma once
#include <DxLib.h>
#include "Card.h"
#include "../User/User.h"
#include "../../Input/KeyInput.h"

class CardManager
{
	Card mCard[NUMBER_NUM];
	User Player[3];
	User Enemy[3];
	InputKey mInput;

	int PlayerPoint;
	int EnemyPoint;

	int count;

	bool DealerFlag;
	bool PlayerFlag;
	bool HitFlag;
	bool ToStand;
	bool ToDraw;
	bool ToWin;
	bool ToFin;

	void CheckStand();
	void CountScore();

public:
	CardManager();

	void Init();

	void Load();

	void Step();

	void Draw();

	void Fin();

	bool GetToDraw() const { return ToDraw; }
	bool GetToWin() const { return ToWin; }
	bool GetToFin() const { return ToFin; }

	void Count() { count--; }
	void SetCount(int c) { count = c; }
	int GetCount() const { return count; }
};

