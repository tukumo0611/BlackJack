
#include "CardManager.h"
using namespace std;

CardManager::CardManager()
{

}

void CardManager::Init()
{
	for (int i = 0; i < NUMBER_NUM; i++) 
		mCard[i].Init();
	for (int i = 0; i < 3; i++) {
		Player[i].Init();
		Enemy[i].Init();
	}
	PlayerPoint = EnemyPoint = 0;
	count = 180;
	DealerFlag = false;
	PlayerFlag = false;
	HitFlag = false;
	ToStand = false;
	ToDraw = false;
	ToWin = false;
	ToFin = false;
}

void CardManager::Load()
{
	for (int i = 0; i < NUMBER_NUM; i++)
		mCard[i].Load(CardHndl[i]);
}

void CardManager::Step()
{
	
	for (int i = 0; i < NUMBER_NUM; i++) {
		if (mCard[i].GetIsActive())
			mCard[i].Step();
	}

	if (!DealerFlag) {
		int DRandNum01 = GetRand(NUMBER_NUM - 1);
		mCard[DRandNum01].SetIsActive(true);
		mCard[DRandNum01].SetIsOPEN(true);
		mCard[DRandNum01].SetMovePos(EnemyCardPos[0]);
		Enemy[0].SetCard(DRandNum01);
		Enemy[0].SetIsActive(true);

		int DRandNum02 = GetRand(NUMBER_NUM - 1);
		if (DRandNum01 != DRandNum02) {
			mCard[DRandNum02].SetIsActive(true);
			mCard[DRandNum02].SetIsOPEN(false);
			mCard[DRandNum02].SetMovePos(EnemyCardPos[1]);
			Enemy[1].SetCard(DRandNum02);
			Enemy[1].SetIsActive(true);
			DealerFlag = true;
		}
	}

	if (!PlayerFlag) {
		while (true) {
			int PRandNum01 = GetRand(NUMBER_NUM - 1);
			if (mCard[PRandNum01].GetIsActive()) continue;
			mCard[PRandNum01].SetIsActive(true);
			mCard[PRandNum01].SetIsOPEN(true);
			mCard[PRandNum01].SetMovePos(PlayerCardPos[0]);
			Player[0].SetCard(PRandNum01);
			Player[0].SetIsActive(true);

			int PRandNum02 = GetRand(NUMBER_NUM - 1);
			if (mCard[PRandNum02].GetIsActive()) continue;
			mCard[PRandNum02].SetIsActive(true);
			mCard[PRandNum02].SetIsOPEN(true);
			mCard[PRandNum02].SetMovePos(PlayerCardPos[1]);
			Player[1].SetCard(PRandNum02);
			Player[1].SetIsActive(true);
			PlayerFlag = true;
			break;
		}
	}

	mInput.Update();
	if (mInput.IsPush(KEY_INPUT_H)) {
		if (HitFlag) return;
		while (true) {
			int PRandNum = GetRand(NUMBER_NUM - 1);
			if (mCard[PRandNum].GetIsActive()) continue;
			mCard[PRandNum].SetIsActive(true);
			mCard[PRandNum].SetIsOPEN(true);
			mCard[PRandNum].SetMovePos(PlayerCardPos[2]);
			Player[2].SetCard(PRandNum);
			Player[2].SetIsActive(true);
			HitFlag = true;
			break;
		}
	}

	if (mInput.IsPush(KEY_INPUT_S)) {
		CountScore();
		mCard[Enemy[1].GetCardNumber()].SetIsOPEN(true);
		ToStand = true;
	}

	if (ToStand) {
		if (GetCount() <= 0)
			CheckStand();
		else
			Count();
	}

}

void CardManager::Draw()
{
	for (int i = 0; i < NUMBER_NUM; i++)
		mCard[i].Draw();
	DrawFormatString(800, 800, GetColor(255, 255, 255), "%d", PlayerPoint);
	DrawFormatString(800, 100, GetColor(255, 255, 255), "%d", EnemyPoint);
}

void CardManager::Fin()
{
	for (int i = 0; i < NUMBER_NUM; i++)
		mCard[i].Fin();

	for (int i = 0; i < 3; i++) {
		Player[i].Fin();
		Enemy[i].Fin();
	}
}

void CardManager::CheckStand()
{
	CountScore();

	ToFin = true;
	int PJack = 21 - PlayerPoint;
	int EJack = 21 - EnemyPoint;
	if (PJack == 0 && EJack == 0) {
		ToDraw = true;
		return;
	}
	else if (PJack == 0) {
		ToWin = true;
		return;
	}
	else if (PJack == 0) {
		ToWin = false;
		return;
	}
	else if (PJack > 0 && EJack < 0) {
		ToWin = true;
		return;
	}
	else if (PJack < 0 && EJack > 0) {
		ToWin = false;
		return;
	}
	else if (PJack < 0 && EJack < 0) {
		if (PJack > EJack) {
			ToWin = true;
			return;
		}
		else if (PJack < EJack) {
			ToWin = false;
			return;
		}
	}
	else if (PJack < EJack) {
		ToWin = true;
		return;
	}
	else if (PJack > EJack) {
		ToWin = false;
		return;
	}

}

void CardManager::CountScore()
{
	PlayerPoint = EnemyPoint = 0;

	for (int i = 0; i < 3; i++) {
		if (Player[i].GetIsActive())
			if (Player[i].GetCardNumber() == 0)
				PlayerPoint += 11;
			else if (Player[i].GetCardNumber() >= 9)
				PlayerPoint += 10;
			else
				PlayerPoint += Player[i].GetCardNumber() + 1;

		if (Enemy[i].GetIsActive())
			if (Enemy[i].GetCardNumber() == 0)
				EnemyPoint += 11;
			else if (Enemy[i].GetCardNumber() >= 9)
				EnemyPoint += 10;
			else
				EnemyPoint += Enemy[i].GetCardNumber() + 1;
	}
}
