
#include "Card.h"
#include "../../Status/Common.h"
#include "../../Status/BaseStatus.h"

Card::Card()
{

}

void Card::Init()
{
	Pos = MovePos = ZERO_VECTOR;
	Hndl = BackHndl = -1;
	Rate = Angle = -1.0;
	IsActive = IsOPEN = false;
}

void Card::Load(const char* CardHndl)
{
	Hndl = LoadGraph(CardHndl);
	BackHndl = LoadGraph(CardBack);
	Pos = MovePos = { 120.0f,120.0f,0.0f };
	Rate = 1.0;
	Angle = 0.0;
}

void Card::Step()
{
	Move(MovePos);
}

void Card::Draw()
{
	if (IsOPEN)
		DrawRotaGraphF(Pos.x, Pos.y, Rate, Angle, Hndl, IsActive);
	else if (!IsOPEN)
		DrawRotaGraphF(Pos.x, Pos.y, Rate, Angle, BackHndl, IsActive);
	else; // �������Ȃ�
}

void Card::Fin()
{
	DeleteGraph(Hndl);
	DeleteGraph(BackHndl);
	Hndl = -1;
	BackHndl = -1;
}

void Card::Move(VECTOR MovePos)
{
	VECTOR movetarget = ZERO_VECTOR;
	movetarget = VSub(MovePos, Pos);
	float length = VSize(movetarget);

	if (length <= 16.0f)
	{
		Pos = MovePos;
		Angle = 0.0;
	}
	else
	{
		Angle += 0.2;

		movetarget = VNorm(movetarget);
		movetarget.x = movetarget.x * MoveSpeed;
		movetarget.y = movetarget.y * MoveSpeed;

		//	���W�ɉ������v�Z���Đi��
		Pos = VAdd(Pos, movetarget);
	}
}
