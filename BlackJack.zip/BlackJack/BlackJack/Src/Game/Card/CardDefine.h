
#pragma once

constexpr float MoveSpeed = 5.0f;

constexpr VECTOR PlayerCardPos[3] = { {600.0f, 675.0f, 0.0f}, { 1000.0f, 675.0f, 0.0f }, { 1400.0f, 675.0f, 0.0f } };

constexpr VECTOR EnemyCardPos[2] = { {1000.0f, 225.0f, 0.0f}, { 600.0f, 225.0f, 0.0f } };

static const char* CardBack = "Data/Card/tramp_back.png";

enum CardState
{
	PLAYER,
	ENEMY
};

enum CardNumber
{
	ONE,
	TWO,
	THREE,
	FOUR,
	FIVE,
	SIX,
	SEVE,
	EIGHT,
	NINE,
	TEN,
	JACK,
	QWEEN,
	KING,
	NUMBER_NUM
};

static const char* CardHndl[NUMBER_NUM] =
{
	"Data/Card/tramp_1.png",		// A
	"Data/Card/tramp_2.png",		// 2
	"Data/Card/tramp_3.png",		// 3
	"Data/Card/tramp_4.png",		// 4
	"Data/Card/tramp_5.png",		// 5
	"Data/Card/tramp_6.png",		// 6
	"Data/Card/tramp_7.png",		// 7
	"Data/Card/tramp_8.png",		// 8
	"Data/Card/tramp_9.png",		// 9
	"Data/Card/tramp_10.png",		// 10
	"Data/Card/tramp_11.png",		// Jack
	"Data/Card/tramp_12.png",		// Qween
	"Data/Card/tramp_13.png"		// King
};
