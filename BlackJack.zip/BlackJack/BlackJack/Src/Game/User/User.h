
#pragma once
#include <DxLib.h>

class User
{
	int Number;
	bool IsActive;

public:
	User() :Number(-1), IsActive(false) {};

	void Init() { Number = -1; IsActive = false; }

	void Fin() { Init(); }

	void SetCard(int number) { Number = number; }
	void SetIsActive(bool flag) { IsActive = flag; }

	int GetCardNumber() const { return Number; }
	bool GetIsActive() const { return IsActive; }

};
