
#include "FrameRate.h"
#include <chrono>
#include <thread>

void FrameRate::Wait() {
    int current_time = GetNowCount();
    int elapsed_time = current_time - last_time;

    if (elapsed_time < frame_duration) {
        std::this_thread::sleep_for(std::chrono::milliseconds(frame_duration - elapsed_time));
    }

    frame_count++;
    if (current_time - last_fps_time >= 1000) {
        fps = frame_count;
        frame_count = 0;
        last_fps_time = current_time;
    }

    last_time = GetNowCount();
}

void FrameRate::Draw()
{
    DrawFormatString(1440, 820, GetColor(255, 255, 255), "FPS: %d/%d", fps, FRAME_TIME);
}
