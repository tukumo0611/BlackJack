
#include "Sound.h"

int SoundManager::m_iHndl[SOUNDID_NUM];

//--------------------------
//�R���X�g���N�^
//--------------------------
SoundManager::SoundManager(void)
{
	Init();
}

//--------------------------
//�f�X�g���N�^
//--------------------------
SoundManager::~SoundManager(void)
{
	Fin();
}

//--------------------------
//������
//--------------------------
void SoundManager::Init(void)
{
	for (int i = 0; i < SOUNDID_NUM; i++)
	{
		m_iHndl[i] = -1;
	}
}

//--------------------------
//�I������
//--------------------------
void SoundManager::Fin(void)
{
	for (int i = 0; i < SOUNDID_NUM; i++)
	{
		if (m_iHndl[i] != -1)
		{
			(m_iHndl[i]);
			m_iHndl[i] = -1;
		}
	}
}

//--------------------------
//�S�f�[�^�ǂݍ���
//--------------------------
void SoundManager::LoadAllData()
{
	bool isRet = true;
	const char pFileName[SOUNDID_NUM][128] =
	{
		"data/sound/bgm00.mp3","data/sound/se_plshot.mp3","data/sound/se_explore.mp3"
	};

	for (int i = 0; i < SOUNDID_NUM; i++)
	{
		m_iHndl[i] = LoadSoundMem(pFileName[i]);
	}

}

//--------------------------
//�Đ����Ԏ擾(�~���b)
//--------------------------
int SoundManager::GetSoundTime(tagSoundID iID)
{
	return (int)GetSoundCurrentTime(m_iHndl[iID]);
}

//--------------------------
//�Đ������Ԏ擾(�~���b)
//--------------------------
int SoundManager::GetSoundAllTime(tagSoundID iID)
{
	return (int)GetSoundTotalTime(m_iHndl[iID]);
}

//--------------------------
//���y�Đ�����
//--------------------------
bool SoundManager::IsPlay(tagSoundID iID)
{
	return CheckSoundMem(m_iHndl[iID]) == 1 ? true : false;
}

//--------------------------
//�Đ��J�n���Ԑݒ�
//--------------------------
void SoundManager::SetStartFrame(tagSoundID iID, int ms)
{
	//�w��ID�̎��g�����擾���Đݒ�
	int iFreq = GetFrequencySoundMem(m_iHndl[iID]) * ms / 1000;
	SetCurrentPositionSoundMem(iFreq, m_iHndl[iID]);
}

//--------------------------
//�{�����[���ݒ�
//--------------------------
void SoundManager::SetVolume(tagSoundID iID, float fVol)
{
	if (fVol < 0.f || fVol>1.f)return;
	ChangeVolumeSoundMem((int)(255.f * fVol), m_iHndl[iID]);
}

//--------------------------
//���y�Đ�
//--------------------------
int SoundManager::Play(tagSoundID iID, int iType, bool isStart)
{
	return PlaySoundMem(m_iHndl[iID], iType, isStart);
}

//--------------------------
//���y��~
//--------------------------
int SoundManager::Stop(tagSoundID iID)
{
	return StopSoundMem(m_iHndl[iID]);
}

//--------------------------
//�S���y��~
//--------------------------
void SoundManager::StopAll(void)
{
	for (int i = 0; i < SOUNDID_NUM; i++)
		StopSoundMem(m_iHndl[i]);
}
