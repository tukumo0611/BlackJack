
#pragma once
#include <DxLib.h>
#include <math.h>

// �x�N�g���N���X
class CVector
{
public:
	static VECTOR Create(VECTOR PosA, VECTOR PosB);     // �쐬
	static float  Long(VECTOR PosA, VECTOR PosB);       // ����
	static float  Long(VECTOR PosA);                    // ����
	static VECTOR Add(VECTOR vecA, VECTOR vecB);        // �����Z
	static VECTOR Subtract(VECTOR vecA, VECTOR vecB);   // �����Z
	static VECTOR Scale(VECTOR vec, float scale);       // �X�J���[�{
	static float  Dot(VECTOR vecA, VECTOR vecB);        // ����
	static VECTOR Cross(VECTOR vecA, VECTOR vecB);      // �O��
	static VECTOR Normalize(VECTOR vec);                // ���K��
	static VECTOR MatTransform(MATRIX mat, VECTOR vec); // �x�N�g���~�s��
	static VECTOR GetPolygonNormalVec(VECTOR vertexA, VECTOR vertexB, VECTOR vertexC);
	static float  GetTriangleHeightXY(VECTOR point, VECTOR vertexA, VECTOR vertexB, VECTOR vertexC);
	static float  GetTriangleHeightXZ(VECTOR point, VECTOR vertexA, VECTOR vertexB, VECTOR vertexC);
	static float  GetTriangleHeightYZ(VECTOR point, VECTOR vertexA, VECTOR vertexB, VECTOR vertexC);
};

//VECTOR operator+(const VECTOR& a, const VECTOR& b) {
//	return CVector::Add(a, b);
//}
//
//VECTOR operator+=(VECTOR& a, const VECTOR& b) {
//	return a = CVector::Add(a, b);
//}